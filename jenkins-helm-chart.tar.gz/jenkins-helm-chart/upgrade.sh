#!/bin/bash
helm upgrade  jenkins jenkins/ -n jenkins
