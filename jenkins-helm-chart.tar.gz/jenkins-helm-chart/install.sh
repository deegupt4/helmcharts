#!/bin/bash
helm install jenkins jenkins/ -n jenkins
