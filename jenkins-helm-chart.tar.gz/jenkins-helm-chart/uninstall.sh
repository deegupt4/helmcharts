#!/bin/bash
helm uninstall jenkins -n jenkins
